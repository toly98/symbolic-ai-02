:-retractall(robot(_)).
:-dynamic robot/1.

% The location of robot and goal
robot(1).
goal(5).

% all links as predicates
link(1,2). % The first link as a predicate
link(2,3).
link(3,4).
link(3,6).
link(6,5).
link(6,7).

adjacent(L):-robot(X),link(X,L).
move(L):-adjacent(L),retract(robot(_)),assertz(robot(L)).
suggest(L):-adjacent(L),goal(L).

path(L,L).
path(L,N):-link(L,M), path(M,N).

append ([X|Y] ,Z ,[X|W]):− append (Y, Z, W).
